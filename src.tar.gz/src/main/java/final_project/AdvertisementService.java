package final_project;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

public class AdvertisementService implements PersistService<Advertisement> {

    private List<Advertisement> advertisements;

    public AdvertisementService() {
        advertisements = new LinkedList<>();
    }

    public void addAdverisement(Advertisement advertisement) {
        advertisements.add(advertisement);
        save(advertisement);
    }

    public void changeAdvertisement(int id, String name, Date date, String text, double price, Author author, Rubric rubric) {
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("jpa_kiril");
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction transaction = entityManager.getTransaction();
        transaction.begin();

//        Advertisement advertisement1 = entityManager.merge(advertisement);
//        entityManager.persist(advertisement1);
        Advertisement advertisement = entityManager.find(Advertisement.class, id);
        Author newAuthor = entityManager.merge(author);
        Rubric newRubric = entityManager.merge(rubric);
//        Advertisement advertisement = getEntityById(id, Advertisement.class);
        advertisement.setName(name);
        advertisement.setDate(date);
        advertisement.setPrice(price);
        advertisement.setText(text);
        advertisement.setAuthor(newAuthor);
        advertisement.setRubric(newRubric);

        transaction.commit();
        entityManager.close();
//        save(advertisement);
    }
}


