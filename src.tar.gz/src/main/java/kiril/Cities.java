package kiril;

public enum Cities {
    KIEV, KHARKOV, DNEPR
}
