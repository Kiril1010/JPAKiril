package kiril;

public enum State {
    KIEV, DNEPR
}
